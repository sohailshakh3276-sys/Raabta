@echo off
title RABTA Flutter Setup Check
echo Checking Flutter...
flutter --version
if errorlevel 1 (
  echo Flutter is not installed or not added to PATH.
  pause
  exit /b 1
)
echo.
echo Checking Android devices...
flutter devices
echo.
echo Getting project packages...
flutter pub get
echo.
echo If no errors appeared, run: flutter run
pause
