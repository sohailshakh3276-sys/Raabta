import 'package:flutter/material.dart';

void main() => runApp(const RabtaApp());

const bg = Color(0xFF0B0B12);
const panel = Color(0xFF171725);
const purple = Color(0xFF8B5CF6);
const muted = Color(0xFFAAA8BB);

class RabtaApp extends StatelessWidget {
  const RabtaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'RABTA',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: bg,
        colorScheme: ColorScheme.fromSeed(
          seedColor: purple,
          brightness: Brightness.dark,
          surface: panel,
        ),
        useMaterial3: true,
        appBarTheme: const AppBarTheme(
          backgroundColor: bg,
          foregroundColor: Colors.white,
          elevation: 0,
        ),
      ),
      home: const PhoneEntryScreen(),
    );
  }
}

class PhoneEntryScreen extends StatefulWidget {
  const PhoneEntryScreen({super.key});
  @override
  State<PhoneEntryScreen> createState() => _PhoneEntryScreenState();
}

class _PhoneEntryScreenState extends State<PhoneEntryScreen> {
  final phone = TextEditingController(text: '+92');
  @override
  void dispose() {
    phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(26),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Spacer(),
              Container(
                height: 76, width: 76,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(24),
                  gradient: const LinearGradient(colors: [purple, Color(0xFF5425B8)]),
                ),
                child: const Icon(Icons.hub_rounded, size: 42, color: Colors.white),
              ),
              const SizedBox(height: 24),
              const Text('RABTA', style: TextStyle(fontSize: 36, fontWeight: FontWeight.w900, letterSpacing: 3)),
              const SizedBox(height: 8),
              const Text('Connect. Share. Discover.', style: TextStyle(color: muted, fontSize: 16)),
              const SizedBox(height: 42),
              const Text('Welcome to RABTA', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
              const SizedBox(height: 8),
              const Text('Enter your mobile number to get started.', style: TextStyle(color: muted)),
              const SizedBox(height: 22),
              TextField(
                controller: phone,
                keyboardType: TextInputType.phone,
                decoration: InputDecoration(
                  labelText: 'Mobile number',
                  hintText: '+92 300 1234567',
                  filled: true, fillColor: panel,
                  prefixIcon: const Icon(Icons.phone_android),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                ),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity, height: 54,
                child: FilledButton(
                  style: FilledButton.styleFrom(backgroundColor: purple, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16))),
                  onPressed: () => showDialog(
                    context: context,
                    builder: (_) => AlertDialog(
                      title: const Text('Setup required'),
                      content: const Text('Real SMS OTP will work after Firebase Phone Authentication is connected. This starter build does not send a real OTP yet.'),
                      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
                    ),
                  ),
                  child: const Text('Continue with phone', style: TextStyle(fontWeight: FontWeight.bold)),
                ),
              ),
              const SizedBox(height: 14),
              Center(child: TextButton(
                onPressed: () => Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => const MainShell())),
                child: const Text('Preview app (demo)', style: TextStyle(color: purple)),
              )),
              const SizedBox(height: 12),
              const Center(child: Text('By continuing, you agree to our Terms and Privacy Policy.', textAlign: TextAlign.center, style: TextStyle(color: muted, fontSize: 11))),
              const Spacer(),
            ],
          ),
        ),
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;
  final pages = const [FeedScreen(), ReelsScreen(), CreateScreen(), ChatsScreen(), ProfileScreen()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('RABTA', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 2)),
        actions: [
          IconButton(onPressed: () => _notice(context, 'Notifications will be connected with the backend.'), icon: const Icon(Icons.notifications_none_rounded)),
        ],
      ),
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        backgroundColor: panel,
        indicatorColor: purple.withOpacity(.25),
        selectedIndex: index,
        onDestinationSelected: (v) => setState(() => index = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.play_circle_outline), selectedIcon: Icon(Icons.play_circle), label: 'Reels'),
          NavigationDestination(icon: Icon(Icons.add_box_outlined), selectedIcon: Icon(Icons.add_box), label: 'Create'),
          NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Chats'),
          NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}

class FeedScreen extends StatelessWidget {
  const FeedScreen({super.key});
  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
      children: [
        const Text('Stories', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        SizedBox(height: 94, child: ListView(scrollDirection: Axis.horizontal, children: const [
          StoryItem(name: 'Your story', add: true), StoryItem(name: 'Ayesha'), StoryItem(name: 'Hamza'), StoryItem(name: 'Zainab'), StoryItem(name: 'Usman'), StoryItem(name: 'Sara'),
        ])),
        const SizedBox(height: 20),
        const Text('Your feed', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        const PostCard(name: 'RABTA Community', handle: '@rabta', caption: 'Welcome to RABTA! Your place to connect, share moments and discover new people. 💜', icon: Icons.hub_rounded),
        const PostCard(name: 'Ayesha Khan', handle: '@ayesha', caption: 'A new day, a fresh start. Keep moving forward! ✨', icon: Icons.face_3_rounded),
      ],
    );
  }
}

class StoryItem extends StatelessWidget {
  final String name; final bool add;
  const StoryItem({super.key, required this.name, this.add = false});
  @override
  Widget build(BuildContext context) => Container(
    width: 72, margin: const EdgeInsets.only(right: 12),
    child: Column(children: [
      Container(
        padding: const EdgeInsets.all(3),
        decoration: BoxDecoration(shape: BoxShape.circle, border: Border.all(color: purple, width: 2)),
        child: CircleAvatar(radius: 27, backgroundColor: panel, child: Icon(add ? Icons.add : Icons.person, color: add ? purple : Colors.white)),
      ),
      const SizedBox(height: 6),
      Text(name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11, color: muted)),
    ]),
  );
}

class PostCard extends StatefulWidget {
  final String name, handle, caption; final IconData icon;
  const PostCard({super.key, required this.name, required this.handle, required this.caption, required this.icon});
  @override
  State<PostCard> createState() => _PostCardState();
}
class _PostCardState extends State<PostCard> {
  bool liked = false;
  @override
  Widget build(BuildContext context) => Card(
    color: panel, margin: const EdgeInsets.only(bottom: 16),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
    child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Row(children: [
        CircleAvatar(backgroundColor: purple.withOpacity(.25), child: Icon(widget.icon, color: purple)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(widget.name, style: const TextStyle(fontWeight: FontWeight.bold)),
          Text(widget.handle, style: const TextStyle(color: muted, fontSize: 12)),
        ])),
        const Icon(Icons.more_horiz, color: muted),
      ]),
      const SizedBox(height: 14),
      Text(widget.caption, style: const TextStyle(fontSize: 14, height: 1.45)),
      const SizedBox(height: 14),
      Container(height: 150, width: double.infinity, decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: const LinearGradient(colors: [Color(0xFF39216B), Color(0xFF171725)], begin: Alignment.topLeft, end: Alignment.bottomRight),
      ), child: const Center(child: Icon(Icons.auto_awesome, size: 48, color: Colors.white70))),
      Row(children: [
        IconButton(onPressed: () => setState(() => liked = !liked), icon: Icon(liked ? Icons.favorite : Icons.favorite_border, color: liked ? Colors.pinkAccent : Colors.white)),
        const Text('Like', style: TextStyle(color: muted)),
        const SizedBox(width: 18),
        IconButton(onPressed: () => _notice(context, 'Comments will be enabled with the backend.'), icon: const Icon(Icons.mode_comment_outlined)),
        const Text('Comment', style: TextStyle(color: muted)),
        const Spacer(),
        IconButton(onPressed: () => _notice(context, 'Sharing will be enabled in the full build.'), icon: const Icon(Icons.share_outlined)),
      ]),
    ])),
  );
}

class ReelsScreen extends StatelessWidget {
  const ReelsScreen({super.key});
  @override
  Widget build(BuildContext context) => Center(child: Padding(
    padding: const EdgeInsets.all(28),
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: const [
      Icon(Icons.play_circle_fill_rounded, size: 76, color: purple),
      SizedBox(height: 18),
      Text('RABTA Reels', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
      SizedBox(height: 8),
      Text('Short videos will appear here. Video upload and playback are part of the next backend-connected build.', textAlign: TextAlign.center, style: TextStyle(color: muted, height: 1.5)),
    ]),
  ));
}

class CreateScreen extends StatelessWidget {
  const CreateScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const Text('Create something', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 8),
    const Text('Share a moment with your RABTA community.', style: TextStyle(color: muted)),
    const SizedBox(height: 22),
    _createTile(context, Icons.edit_note, 'Write a post', 'Share text and updates'),
    _createTile(context, Icons.photo_library_outlined, 'Photo or video', 'Upload media from your phone'),
    _createTile(context, Icons.add_circle_outline, 'Create a story', 'A moment that lasts 24 hours'),
    _createTile(context, Icons.video_collection_outlined, 'Upload a reel', 'Share a short video'),
  ]);
  Widget _createTile(BuildContext c, IconData i, String t, String s) => Card(color: panel, child: ListTile(
    leading: Icon(i, color: purple, size: 28), title: Text(t, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text(s, style: const TextStyle(color: muted)),
    trailing: const Icon(Icons.chevron_right),
    onTap: () => _notice(c, '$t will be enabled in the full backend-connected build.'),
  ));
}

class ChatsScreen extends StatelessWidget {
  const ChatsScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Messages', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
    const SizedBox(height: 14),
    TextField(decoration: InputDecoration(hintText: 'Search chats', prefixIcon: const Icon(Icons.search), filled: true, fillColor: panel, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none))),
    const SizedBox(height: 14),
    _chat(context, 'Ayesha Khan', 'Hi! Welcome to RABTA.', '2m', Icons.face_3),
    _chat(context, 'Family Group', 'Usman: Assalam-o-alaikum', '15m', Icons.groups),
    _chat(context, 'Hamza Ali', 'Send me the photos please.', '1h', Icons.person),
    const SizedBox(height: 18),
    const Text('Demo conversations only. Real-time private messaging, group chat, calls and encryption require backend setup.', style: TextStyle(color: muted, height: 1.5)),
  ]);
  Widget _chat(BuildContext c, String name, String msg, String time, IconData icon) => ListTile(
    contentPadding: const EdgeInsets.symmetric(vertical: 5),
    leading: CircleAvatar(backgroundColor: purple.withOpacity(.25), child: Icon(icon, color: purple)),
    title: Text(name, style: const TextStyle(fontWeight: FontWeight.bold)),
    subtitle: Text(msg, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(color: muted)),
    trailing: Text(time, style: const TextStyle(color: muted, fontSize: 11)),
    onTap: () => _notice(c, 'Real chat will be connected in the backend build.'),
  );
}

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});
  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [
    const SizedBox(height: 18),
    const Center(child: CircleAvatar(radius: 48, backgroundColor: panel, child: Icon(Icons.person, size: 52, color: purple))),
    const SizedBox(height: 14),
    const Center(child: Text('Your RABTA Profile', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold))),
    const Center(child: Text('@yourusername', style: TextStyle(color: muted))),
    const SizedBox(height: 22),
    const Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: [
      _Stat(value: '0', label: 'Posts'), _Stat(value: '0', label: 'Followers'), _Stat(value: '0', label: 'Following'),
    ]),
    const SizedBox(height: 26),
    _profileOption(context, Icons.edit, 'Edit profile'),
    _profileOption(context, Icons.lock_outline, 'Privacy and security'),
    _profileOption(context, Icons.settings_outlined, 'Settings'),
    _profileOption(context, Icons.help_outline, 'Help and support'),
  ]);
  Widget _profileOption(BuildContext c, IconData i, String t) => Card(color: panel, child: ListTile(
    leading: Icon(i, color: purple), title: Text(t), trailing: const Icon(Icons.chevron_right),
    onTap: () => _notice(c, '$t will be available in the connected release.'),
  ));
}
class _Stat extends StatelessWidget {
  final String value, label;
  const _Stat({required this.value, required this.label});
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
    Text(label, style: const TextStyle(color: muted)),
  ]);
}

void _notice(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message), behavior: SnackBarBehavior.floating));
}
