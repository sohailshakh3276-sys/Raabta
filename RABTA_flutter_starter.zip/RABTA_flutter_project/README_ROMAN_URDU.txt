RABTA - Flutter Android Starter Project
=======================================

Ye RABTA ka pehla runnable UI prototype hai. Is mein dark premium design,
phone entry screen, Home feed, Stories, Reels tab, Create tab, Chats list
aur Profile screen ka interface diya gaya hai.

ZAROORI HAQEEQAT:
- Ye abhi production social network nahi hai.
- Phone number screen abhi real SMS OTP nahi bhejti.
- Demo preview button se app ka interface dekha ja sakta hai.
- Posts, chat, media uploads, calls, notifications aur encryption ko real
  banane ke liye backend, authentication, database, storage aur testing
  connect karna zaroori hai.
- Is starter mein koi fake OTP ya fake security claim nahi hai.

WINDOWS PAR CHALANE KA TAREEQA:
1. Flutter SDK aur Android Studio install karein.
2. ZIP extract karein.
3. RABTA folder ke andar CMD kholein.
4. Ye commands chalayein:

   flutter doctor
   flutter pub get
   flutter run

Agar Android phone par chalana ho:
- Phone mein Developer Options aur USB debugging enable karein.
- USB cable se laptop connect karein.
- CMD mein `flutter devices` chalayein.
- Phir `flutter run` chalayein.

NEXT DEVELOPMENT STAGE:
1. Firebase project banana aur Android app register karna.
2. Firebase Phone Authentication (real OTP) configure karna.
3. Firestore database aur Storage rules banana.
4. User profiles, posts, follows, comments, stories aur reels implement karna.
5. Real-time one-to-one/group messaging implement karna.
6. Voice/video calling aur push notifications integrate karna.
7. Security rules, abuse reporting, privacy, load testing aur release signing.

App package name ko final release se pehle unique karna hoga.
